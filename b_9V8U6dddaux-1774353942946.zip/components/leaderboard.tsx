"use client"

import { motion } from "framer-motion"
import { Trophy, Medal, Award, Crown } from "lucide-react"

export interface Contributor {
  id: string
  name: string
  amount: number
}

interface LeaderboardProps {
  contributors: Contributor[]
  title?: string
  maxItems?: number
}

const rankConfig = [
  {
    icon: Crown,
    iconColor: "text-amber-400",
    bgGradient: "from-amber-500/20 to-amber-600/10",
    borderColor: "border-amber-400/60",
    glowColor: "shadow-[0_0_25px_rgba(251,191,36,0.35)]",
    amountColor: "text-amber-400",
    nameColor: "text-amber-100",
    rankBg: "bg-gradient-to-br from-amber-400 to-amber-600",
  },
  {
    icon: Medal,
    iconColor: "text-slate-300",
    bgGradient: "from-slate-400/15 to-slate-500/10",
    borderColor: "border-slate-400/50",
    glowColor: "shadow-[0_0_20px_rgba(203,213,225,0.25)]",
    amountColor: "text-slate-300",
    nameColor: "text-slate-200",
    rankBg: "bg-gradient-to-br from-slate-300 to-slate-500",
  },
  {
    icon: Award,
    iconColor: "text-orange-400",
    bgGradient: "from-orange-500/15 to-orange-600/10",
    borderColor: "border-orange-400/50",
    glowColor: "shadow-[0_0_20px_rgba(251,146,60,0.25)]",
    amountColor: "text-orange-400",
    nameColor: "text-orange-100",
    rankBg: "bg-gradient-to-br from-orange-400 to-orange-600",
  },
]

const defaultConfig = {
  icon: null,
  iconColor: "text-white/60",
  bgGradient: "from-white/5 to-white/10",
  borderColor: "border-white/10",
  glowColor: "",
  amountColor: "text-purple-400",
  nameColor: "text-white",
  rankBg: "bg-white/10",
}

export function Leaderboard({ 
  contributors, 
  title = "Top Supporters",
  maxItems = 10 
}: LeaderboardProps) {
  const sortedContributors = [...contributors]
    .sort((a, b) => b.amount - a.amount)
    .slice(0, maxItems)

  return (
    <div className="h-full flex flex-col rounded-2xl bg-black/60 backdrop-blur-xl border border-purple-500/30 p-4 shadow-[0_0_40px_rgba(168,85,247,0.15)]">
      {/* Header */}
      <div className="flex items-center gap-3 mb-4 pb-3 border-b border-purple-500/30">
        <div className="p-2 rounded-lg bg-purple-500/20">
          <Trophy className="h-5 w-5 text-purple-400" />
        </div>
        <h2 className="text-xl font-bold text-white">{title}</h2>
      </div>

      {/* Scrollable leaderboard list */}
      <div className="flex-1 overflow-y-auto space-y-2 pr-2 custom-scrollbar">
        {sortedContributors.map((contributor, index) => {
          const config = index < 3 ? rankConfig[index] : defaultConfig
          const IconComponent = index < 3 ? rankConfig[index].icon : null

          return (
            <motion.div
              key={contributor.id}
              initial={{ x: 50, opacity: 0 }}
              animate={{ x: 0, opacity: 1 }}
              transition={{ delay: index * 0.08, type: "spring", stiffness: 100 }}
              className={`
                flex items-center gap-3 p-3 rounded-xl
                bg-gradient-to-r ${config.bgGradient}
                border ${config.borderColor}
                ${config.glowColor}
                transition-all duration-300 hover:scale-[1.02]
              `}
            >
              {/* Rank badge */}
              <div className={`
                flex items-center justify-center w-8 h-8 rounded-full
                ${config.rankBg}
                ${index < 3 ? "text-black" : ""}
              `}>
                {IconComponent ? (
                  <IconComponent className="h-4 w-4" />
                ) : (
                  <span className="text-sm font-bold text-white/80">{index + 1}</span>
                )}
              </div>

              {/* Name */}
              <div className="flex-1 min-w-0">
                <span className={`font-semibold truncate block ${config.nameColor}`}>
                  {contributor.name}
                </span>
              </div>

              {/* Amount */}
              <div className={`text-sm font-bold whitespace-nowrap ${config.amountColor}`}>
                ₦{contributor.amount.toLocaleString()}
              </div>
            </motion.div>
          )
        })}

        {sortedContributors.length === 0 && (
          <div className="flex flex-col items-center justify-center h-32 text-white/40 gap-2">
            <Trophy className="h-8 w-8 opacity-50" />
            <span>No donations yet</span>
          </div>
        )}
      </div>
    </div>
  )
}
