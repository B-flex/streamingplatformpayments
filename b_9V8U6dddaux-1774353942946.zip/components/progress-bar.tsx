"use client"

import { motion } from "framer-motion"
import { Target, Sparkles } from "lucide-react"
import { useEffect, useState, useRef } from "react"

interface ProgressBarProps {
  currentAmount: number
  goalAmount: number
  title?: string
  showPercentage?: boolean
  showAmount?: boolean
}

export function ProgressBar({
  currentAmount,
  goalAmount,
  title = "Donation Goal",
  showPercentage = true,
  showAmount = true,
}: ProgressBarProps) {
  const percentage = Math.min((currentAmount / goalAmount) * 100, 100)
  const prevAmountRef = useRef(currentAmount)
  const [isGlowing, setIsGlowing] = useState(false)
  const [animatedPercentage, setAnimatedPercentage] = useState(0)

  // Animate percentage with requestAnimationFrame for smooth updates
  useEffect(() => {
    let animationFrame: number
    const targetPercentage = percentage
    const duration = 800
    const startTime = performance.now()
    const startValue = animatedPercentage

    const animate = (currentTime: number) => {
      const elapsed = currentTime - startTime
      const progress = Math.min(elapsed / duration, 1)
      
      // Ease out cubic
      const easeOut = 1 - Math.pow(1 - progress, 3)
      const newValue = startValue + (targetPercentage - startValue) * easeOut
      
      setAnimatedPercentage(Math.round(newValue))
      
      if (progress < 1) {
        animationFrame = requestAnimationFrame(animate)
      }
    }

    animationFrame = requestAnimationFrame(animate)
    return () => cancelAnimationFrame(animationFrame)
  }, [percentage])

  useEffect(() => {
    if (currentAmount > prevAmountRef.current) {
      setIsGlowing(true)
      const timer = setTimeout(() => setIsGlowing(false), 1500)
      return () => clearTimeout(timer)
    }
    prevAmountRef.current = currentAmount
  }, [currentAmount])

  return (
    <div className="w-full">
      <div className="flex items-center justify-between mb-3">
        <div className="flex items-center gap-2">
          <Target className="h-5 w-5 text-cyan-400" />
          <span className="text-white font-medium">{title}</span>
          {isGlowing && (
            <motion.div
              initial={{ scale: 0, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0, opacity: 0 }}
            >
              <Sparkles className="h-4 w-4 text-yellow-400" />
            </motion.div>
          )}
        </div>
        {showAmount && (
          <div className="flex items-center gap-2">
            <motion.span
              key={currentAmount}
              initial={{ scale: 1.2, color: "#22d3ee" }}
              animate={{ scale: 1, color: "#22d3ee" }}
              className="text-2xl font-bold"
            >
              ₦{currentAmount.toLocaleString()}
            </motion.span>
            <span className="text-white/50">/</span>
            <span className="text-lg text-white/70">₦{goalAmount.toLocaleString()}</span>
          </div>
        )}
      </div>

      <div className="relative h-7 rounded-full bg-white/10 border border-white/20 overflow-hidden">
        <motion.div
          animate={{
            opacity: isGlowing ? [0.5, 1, 0.5] : 0.3,
            scale: isGlowing ? [1, 1.02, 1] : 1,
          }}
          transition={{
            duration: isGlowing ? 0.5 : 2,
            repeat: isGlowing ? 2 : Infinity,
            ease: "easeInOut",
          }}
          className="absolute inset-0 bg-gradient-to-r from-green-500/30 via-cyan-500/30 to-purple-500/30 rounded-full"
          style={{
            boxShadow: isGlowing
              ? "0 0 30px rgba(34, 211, 238, 0.6), 0 0 60px rgba(168, 85, 247, 0.4)"
              : "none",
          }}
        />

        <motion.div
          initial={{ width: 0 }}
          animate={{ width: `${percentage}%` }}
          transition={{ type: "spring", stiffness: 50, damping: 15 }}
          className="absolute inset-y-0 left-0 rounded-full overflow-hidden"
          style={{
            boxShadow: isGlowing
              ? "0 0 20px rgba(34, 211, 238, 0.8), 0 0 40px rgba(168, 85, 247, 0.6)"
              : "0 0 10px rgba(34, 211, 238, 0.4)",
          }}
        >
          <div className="absolute inset-0 bg-gradient-to-r from-green-500 via-cyan-500 to-purple-500" />

          {isGlowing && (
            <motion.div
              animate={{ opacity: [0.3, 0.7, 0.3] }}
              transition={{ duration: 0.4, repeat: Infinity }}
              className="absolute inset-0 bg-white/30"
            />
          )}

          <motion.div
            animate={{ x: ["-100%", "200%"] }}
            transition={{
              duration: 2,
              repeat: Infinity,
              ease: "linear",
              repeatDelay: 1,
            }}
            className="absolute inset-0 bg-gradient-to-r from-transparent via-white/40 to-transparent skew-x-12"
          />
        </motion.div>

        {showPercentage && (
          <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
            <span className="text-sm font-bold text-white drop-shadow-lg">
              {animatedPercentage}%
            </span>
          </div>
        )}
      </div>

      <div className="relative mt-1 h-2">
        {[25, 50, 75, 100].map((milestone) => (
          <div
            key={milestone}
            className="absolute top-0 transform -translate-x-1/2"
            style={{ left: `${milestone}%` }}
          >
            <div
              className={`w-1 h-2 rounded-full ${
                percentage >= milestone ? "bg-cyan-400" : "bg-white/20"
              }`}
            />
          </div>
        ))}
      </div>
    </div>
  )
}
