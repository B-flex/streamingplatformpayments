"use client"

import { motion, AnimatePresence } from "framer-motion"
import { Sparkles, Zap, Crown } from "lucide-react"

interface DonationAlertProps {
  senderName: string
  amount: number
  isVisible: boolean
}

type DonationTier = "small" | "medium" | "large"

function getDonationTier(amount: number): DonationTier {
  if (amount >= 100) return "large"
  if (amount >= 25) return "medium"
  return "small"
}

const tierStyles: Record<DonationTier, { gradient: string; glow: string; icon: React.ReactNode }> = {
  small: {
    gradient: "from-emerald-500 via-teal-400 to-cyan-500",
    glow: "shadow-[0_0_60px_rgba(16,185,129,0.5)]",
    icon: <Sparkles className="h-12 w-12 text-emerald-400" />,
  },
  medium: {
    gradient: "from-blue-500 via-purple-500 to-pink-500",
    glow: "shadow-[0_0_80px_rgba(139,92,246,0.6)]",
    icon: <Zap className="h-14 w-14 text-purple-400" />,
  },
  large: {
    gradient: "from-amber-400 via-orange-500 to-rose-500",
    glow: "shadow-[0_0_120px_rgba(251,146,60,0.7)]",
    icon: <Crown className="h-16 w-16 text-amber-400" />,
  },
}

export function DonationAlert({ senderName, amount, isVisible }: DonationAlertProps) {
  const tier = getDonationTier(amount)
  const styles = tierStyles[tier]
  const isPulsing = tier === "large"

  return (
    <AnimatePresence>
      {isVisible && (
        <motion.div
          initial={{ scale: 0, opacity: 0 }}
          animate={{ scale: 1.2, opacity: 1 }}
          exit={{ scale: 0.8, opacity: 0 }}
          transition={{
            type: "spring",
            stiffness: 260,
            damping: 20,
          }}
          className="relative"
        >
          {/* Outer glow ring */}
          <motion.div
            animate={{
              scale: [1, 1.15, 1],
              opacity: [0.4, 0.7, 0.4],
            }}
            transition={{
              duration: 1.5,
              repeat: Infinity,
              ease: "easeInOut",
            }}
            className={`absolute inset-0 rounded-3xl bg-gradient-to-r ${styles.gradient} blur-2xl opacity-50`}
          />

          {/* Main card */}
          <motion.div
            animate={isPulsing ? {
              boxShadow: [
                "0 0 60px rgba(251,146,60,0.4)",
                "0 0 100px rgba(251,146,60,0.7)",
                "0 0 60px rgba(251,146,60,0.4)",
              ],
            } : {}}
            transition={isPulsing ? {
              duration: 1,
              repeat: Infinity,
              ease: "easeInOut",
            } : {}}
            className={`relative rounded-3xl bg-black/80 backdrop-blur-xl border-2 border-white/20 p-10 ${styles.glow}`}
          >
            {/* Animated border */}
            <div
              className={`absolute inset-0 rounded-3xl bg-gradient-to-r ${styles.gradient} opacity-20`}
            />

            <div className="relative flex flex-col items-center gap-6">
              {/* Icon with pulse effect */}
              <motion.div
                animate={{
                  scale: [1, 1.2, 1],
                }}
                transition={{
                  duration: 1.5,
                  repeat: Infinity,
                  ease: "easeInOut",
                }}
              >
                {styles.icon}
              </motion.div>

              {/* Main donation message */}
              <motion.div
                initial={{ y: 20, opacity: 0 }}
                animate={{ y: 0, opacity: 1 }}
                transition={{ delay: 0.2 }}
                className="flex flex-col items-center gap-2"
              >
                <span className="text-3xl font-bold text-white">
                  {senderName}
                </span>
                <span className="text-xl text-white/70">sent</span>
                <span className={`text-5xl font-black bg-gradient-to-r ${styles.gradient} bg-clip-text text-transparent`}>
                  ₦{amount.toLocaleString()}
                </span>
              </motion.div>

              {/* Thank you message */}
              <motion.div
                initial={{ y: 20, opacity: 0 }}
                animate={{ y: 0, opacity: 1 }}
                transition={{ delay: 0.4 }}
                className="text-lg text-white/60"
              >
                Thank you for your support!
              </motion.div>
            </div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  )
}
