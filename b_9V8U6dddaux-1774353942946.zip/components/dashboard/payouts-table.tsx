"use client"

import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table"
import { Badge } from "@/components/ui/badge"
import { format } from "date-fns"
import { ArrowUpRight, Clock, CheckCircle2, XCircle } from "lucide-react"

export interface Payout {
  id: string
  amount: number
  status: "completed" | "pending" | "failed"
  bankName: string
  accountNumber: string
  createdAt: Date
  completedAt?: Date
}

interface PayoutsTableProps {
  payouts: Payout[]
  title?: string
}

const statusConfig = {
  completed: {
    label: "Completed",
    icon: CheckCircle2,
    className: "bg-emerald-500/20 text-emerald-400 border-emerald-500/30",
  },
  pending: {
    label: "Pending",
    icon: Clock,
    className: "bg-amber-500/20 text-amber-400 border-amber-500/30",
  },
  failed: {
    label: "Failed",
    icon: XCircle,
    className: "bg-red-500/20 text-red-400 border-red-500/30",
  },
}

export function PayoutsTable({ payouts, title = "Recent Payouts" }: PayoutsTableProps) {
  return (
    <div className="bg-zinc-900/80 border border-zinc-800 rounded-xl overflow-hidden">
      <div className="flex items-center justify-between p-6 border-b border-zinc-800">
        <h3 className="text-lg font-semibold text-white">{title}</h3>
        <button className="flex items-center gap-1 text-sm text-purple-400 hover:text-purple-300 transition-colors">
          View all
          <ArrowUpRight className="h-4 w-4" />
        </button>
      </div>
      <div className="overflow-x-auto">
        <Table>
          <TableHeader>
            <TableRow className="border-zinc-800 hover:bg-transparent">
              <TableHead className="text-zinc-400 font-medium">Amount</TableHead>
              <TableHead className="text-zinc-400 font-medium">Bank</TableHead>
              <TableHead className="text-zinc-400 font-medium">Account</TableHead>
              <TableHead className="text-zinc-400 font-medium">Date</TableHead>
              <TableHead className="text-zinc-400 font-medium">Status</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {payouts.map((payout) => {
              const status = statusConfig[payout.status]
              const StatusIcon = status.icon
              return (
                <TableRow
                  key={payout.id}
                  className="border-zinc-800 hover:bg-zinc-800/50 transition-colors"
                >
                  <TableCell className="font-semibold text-white">
                    ₦{payout.amount.toLocaleString()}
                  </TableCell>
                  <TableCell className="text-zinc-300">{payout.bankName}</TableCell>
                  <TableCell className="text-zinc-400 font-mono text-sm">
                    ****{payout.accountNumber.slice(-4)}
                  </TableCell>
                  <TableCell className="text-zinc-400">
                    {format(payout.createdAt, "MMM d, yyyy")}
                  </TableCell>
                  <TableCell>
                    <Badge
                      variant="outline"
                      className={status.className}
                    >
                      <StatusIcon className="h-3 w-3 mr-1" />
                      {status.label}
                    </Badge>
                  </TableCell>
                </TableRow>
              )
            })}
          </TableBody>
        </Table>
      </div>
    </div>
  )
}
