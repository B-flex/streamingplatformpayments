"use client"

import { useState, useEffect, useCallback } from "react"
import { DonationAlert } from "./donation-alert"
import { Leaderboard } from "./leaderboard"
import { ProgressBar } from "./progress-bar"
import { TopBar } from "./top-bar"

interface Donation {
  id: string
  senderName: string
  amount: number
  timestamp: number
}

interface Contributor {
  id: string
  name: string
  amount: number
}

// Demo data - in production, this would come from a WebSocket or API
const DEMO_DONATIONS: Omit<Donation, "id" | "timestamp">[] = [
  { senderName: "StreamFan2024", amount: 5 },
  { senderName: "GamerPro99", amount: 25 },
  { senderName: "NightOwl_Sarah", amount: 50 },
  { senderName: "TechWizard", amount: 100 },
  { senderName: "CoolDude42", amount: 10 },
  { senderName: "MegaSupporter", amount: 250 },
  { senderName: "CasualViewer", amount: 3 },
]

export function Overlay() {
  const [currentAlert, setCurrentAlert] = useState<Donation | null>(null)
  const [showAlert, setShowAlert] = useState(false)
  const [latestDonor, setLatestDonor] = useState<{ name: string; amount: number } | null>(null)
  const [contributors, setContributors] = useState<Contributor[]>([
    { id: "1", name: "StreamFan2024", amount: 150 },
    { id: "2", name: "GamerPro99", amount: 125 },
    { id: "3", name: "NightOwl_Sarah", amount: 100 },
    { id: "4", name: "TechWizard", amount: 75 },
    { id: "5", name: "CoolDude42", amount: 50 },
  ])
  const [totalDonations, setTotalDonations] = useState(500)
  const [demoIndex, setDemoIndex] = useState(0)

  const GOAL = 1500

  const processDonation = useCallback((donation: Omit<Donation, "id" | "timestamp">) => {
    const fullDonation: Donation = {
      ...donation,
      id: crypto.randomUUID(),
      timestamp: Date.now(),
    }

    // Update latest donor
    setLatestDonor({ name: donation.senderName, amount: donation.amount })

    // Update total
    setTotalDonations((prev) => prev + donation.amount)

    // Update contributors
    setContributors((prev) => {
      const existing = prev.find((c) => c.name === donation.senderName)
      if (existing) {
        return prev.map((c) =>
          c.name === donation.senderName ? { ...c, amount: c.amount + donation.amount } : c
        )
      }
      return [...prev, { id: crypto.randomUUID(), name: donation.senderName, amount: donation.amount }]
    })

    // Show alert
    setCurrentAlert(fullDonation)
    setShowAlert(true)

    // Hide alert after duration based on amount
    const duration = donation.amount >= 100 ? 6000 : donation.amount >= 25 ? 4500 : 3000
    setTimeout(() => {
      setShowAlert(false)
    }, duration)
  }, [])

  // Demo mode: simulate incoming donations
  useEffect(() => {
    const interval = setInterval(() => {
      if (!showAlert) {
        const donation = DEMO_DONATIONS[demoIndex % DEMO_DONATIONS.length]
        processDonation(donation)
        setDemoIndex((prev) => prev + 1)
      }
    }, 8000)

    return () => clearInterval(interval)
  }, [demoIndex, showAlert, processDonation])

  // Trigger first donation after mount
  useEffect(() => {
    const timer = setTimeout(() => {
      processDonation(DEMO_DONATIONS[0])
      setDemoIndex(1)
    }, 2000)

    return () => clearTimeout(timer)
  }, [processDonation])

  return (
    <div className="fixed inset-0 overflow-hidden bg-[#0a0014]">
      {/* Animated background */}
      <div className="absolute inset-0 opacity-30">
        <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-purple-600 rounded-full blur-[128px] animate-pulse" />
        <div className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-blue-600 rounded-full blur-[128px] animate-pulse" style={{ animationDelay: "1s" }} />
        <div className="absolute top-1/2 left-1/2 w-64 h-64 bg-pink-600 rounded-full blur-[96px] animate-pulse" style={{ animationDelay: "2s" }} />
      </div>

      {/* Grid overlay for cyberpunk effect */}
      <div
        className="absolute inset-0 opacity-10"
        style={{
          backgroundImage: `
            linear-gradient(rgba(139, 92, 246, 0.3) 1px, transparent 1px),
            linear-gradient(90deg, rgba(139, 92, 246, 0.3) 1px, transparent 1px)
          `,
          backgroundSize: "50px 50px",
        }}
      />

      {/* Content */}
      <div className="relative h-full flex flex-col p-6">
        {/* Top bar */}
        <div className="flex-shrink-0">
          <TopBar latestDonor={latestDonor} />
        </div>

        {/* Main content area */}
        <div className="flex-1 flex items-center justify-center relative min-h-0">
          {/* Center: Donation Alert */}
          <div className="flex items-center justify-center">
            {currentAlert && (
              <DonationAlert
                senderName={currentAlert.senderName}
                amount={currentAlert.amount}
                isVisible={showAlert}
              />
            )}
          </div>

          {/* Right: Leaderboard */}
          <div className="absolute right-0 top-1/2 -translate-y-1/2 w-72 h-96 p-4 rounded-2xl bg-black/40 backdrop-blur-xl border border-purple-500/30">
            <Leaderboard contributors={contributors} />
          </div>
        </div>

        {/* Bottom: Progress bar */}
        <div className="flex-shrink-0 max-w-3xl mx-auto w-full">
          <ProgressBar currentAmount={totalDonations} goalAmount={GOAL} />
        </div>
      </div>
    </div>
  )
}
