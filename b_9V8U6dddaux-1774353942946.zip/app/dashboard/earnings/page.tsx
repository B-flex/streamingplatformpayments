"use client"

import { EarningsSummaryCard } from "@/components/dashboard/earnings-summary-card"
import { EarningsChart } from "@/components/dashboard/earnings-chart"
import { PayoutsTable, type Payout } from "@/components/dashboard/payouts-table"
import { Wallet, Calendar, CalendarDays, TrendingUp, ArrowDownToLine } from "lucide-react"

// Sample data - in production, fetch from API
const weeklyData = [
  { label: "Mon", amount: 25000 },
  { label: "Tue", amount: 42000 },
  { label: "Wed", amount: 18000 },
  { label: "Thu", amount: 65000 },
  { label: "Fri", amount: 38000 },
  { label: "Sat", amount: 72000 },
  { label: "Sun", amount: 55000 },
]

const monthlyData = [
  { label: "Week 1", amount: 185000 },
  { label: "Week 2", amount: 210000 },
  { label: "Week 3", amount: 175000 },
  { label: "Week 4", amount: 245000 },
]

const recentPayouts: Payout[] = [
  {
    id: "1",
    amount: 150000,
    status: "completed",
    bankName: "GTBank",
    accountNumber: "0123456789",
    createdAt: new Date(Date.now() - 1000 * 60 * 60 * 24 * 2),
    completedAt: new Date(Date.now() - 1000 * 60 * 60 * 24 * 2),
  },
  {
    id: "2",
    amount: 85000,
    status: "completed",
    bankName: "GTBank",
    accountNumber: "0123456789",
    createdAt: new Date(Date.now() - 1000 * 60 * 60 * 24 * 7),
    completedAt: new Date(Date.now() - 1000 * 60 * 60 * 24 * 7),
  },
  {
    id: "3",
    amount: 200000,
    status: "pending",
    bankName: "GTBank",
    accountNumber: "0123456789",
    createdAt: new Date(Date.now() - 1000 * 60 * 60 * 12),
  },
  {
    id: "4",
    amount: 120000,
    status: "completed",
    bankName: "GTBank",
    accountNumber: "0123456789",
    createdAt: new Date(Date.now() - 1000 * 60 * 60 * 24 * 14),
    completedAt: new Date(Date.now() - 1000 * 60 * 60 * 24 * 14),
  },
  {
    id: "5",
    amount: 50000,
    status: "failed",
    bankName: "GTBank",
    accountNumber: "0123456789",
    createdAt: new Date(Date.now() - 1000 * 60 * 60 * 24 * 10),
  },
]

// Calculate summary values
const todayEarnings = 55000
const yesterdayEarnings = 48000
const weeklyEarnings = weeklyData.reduce((sum, d) => sum + d.amount, 0)
const previousWeekEarnings = 285000
const monthlyEarnings = monthlyData.reduce((sum, d) => sum + d.amount, 0)
const previousMonthEarnings = 720000
const totalEarnings = 2450000
const availableBalance = 200000

export default function EarningsPage() {
  return (
    <div className="p-6 lg:p-8 space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div className="space-y-1">
          <h1 className="text-2xl font-bold text-white">Earnings</h1>
          <p className="text-zinc-500">Track your income and manage payouts.</p>
        </div>
        <button className="flex items-center justify-center gap-2 px-4 py-2.5 bg-gradient-to-r from-purple-500 to-pink-500 text-white font-medium rounded-lg hover:opacity-90 transition-opacity">
          <ArrowDownToLine className="h-4 w-4" />
          Withdraw Funds
        </button>
      </div>

      {/* Summary Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-4">
        <EarningsSummaryCard
          title="Total Earnings"
          amount={totalEarnings}
          icon={Wallet}
          accentColor="purple"
          glowing
        />
        <EarningsSummaryCard
          title="Today"
          amount={todayEarnings}
          previousAmount={yesterdayEarnings}
          icon={Calendar}
          accentColor="green"
        />
        <EarningsSummaryCard
          title="This Week"
          amount={weeklyEarnings}
          previousAmount={previousWeekEarnings}
          icon={CalendarDays}
          accentColor="cyan"
        />
        <EarningsSummaryCard
          title="This Month"
          amount={monthlyEarnings}
          previousAmount={previousMonthEarnings}
          icon={TrendingUp}
          accentColor="amber"
        />
      </div>

      {/* Available Balance Banner */}
      <div className="relative overflow-hidden rounded-xl border border-purple-500/30 bg-gradient-to-r from-purple-500/10 via-pink-500/10 to-purple-500/10 p-6">
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top_right,_var(--tw-gradient-stops))] from-purple-500/20 via-transparent to-transparent" />
        <div className="relative flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
          <div className="space-y-1">
            <p className="text-sm text-zinc-400">Available for Withdrawal</p>
            <p className="text-4xl font-bold text-white">₦{availableBalance.toLocaleString()}</p>
            <p className="text-xs text-zinc-500">Minimum withdrawal: ₦5,000</p>
          </div>
          <div className="flex items-center gap-3">
            <div className="text-right hidden sm:block">
              <p className="text-xs text-zinc-400">Processing Time</p>
              <p className="text-sm text-white font-medium">Instant - 24hrs</p>
            </div>
            <div className="h-10 w-px bg-zinc-700 hidden sm:block" />
            <div className="text-right hidden sm:block">
              <p className="text-xs text-zinc-400">Withdrawal Fee</p>
              <p className="text-sm text-emerald-400 font-medium">Free</p>
            </div>
          </div>
        </div>
      </div>

      {/* Charts Grid */}
      <div className="grid grid-cols-1 xl:grid-cols-2 gap-6">
        <EarningsChart data={weeklyData} title="Weekly Earnings" />
        <EarningsChart data={monthlyData} title="Monthly Breakdown" />
      </div>

      {/* Recent Payouts */}
      <PayoutsTable payouts={recentPayouts} />
    </div>
  )
}
