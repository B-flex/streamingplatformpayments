"use client"

import { useState } from "react"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { Switch } from "@/components/ui/switch"
import { 
  User, 
  Mail, 
  Moon, 
  Sun, 
  Volume2, 
  Sparkles, 
  Save,
  Check
} from "lucide-react"
import { cn } from "@/lib/utils"

interface ProfileData {
  name: string
  email: string
}

interface AppSettings {
  darkMode: boolean
  soundEffects: boolean
  donationAnimations: boolean
}

export default function SettingsPage() {
  const [profile, setProfile] = useState<ProfileData>({
    name: "Alex Johnson",
    email: "alex@streamtip.com",
  })

  const [settings, setSettings] = useState<AppSettings>({
    darkMode: true,
    soundEffects: true,
    donationAnimations: true,
  })

  const [isSaving, setIsSaving] = useState(false)
  const [saved, setSaved] = useState(false)

  const handleProfileChange = (field: keyof ProfileData, value: string) => {
    setProfile((prev) => ({ ...prev, [field]: value }))
    setSaved(false)
  }

  const handleSettingToggle = (setting: keyof AppSettings) => {
    setSettings((prev) => ({ ...prev, [setting]: !prev[setting] }))
    setSaved(false)
  }

  const handleSave = async () => {
    setIsSaving(true)
    // Simulate API call
    await new Promise((resolve) => setTimeout(resolve, 1000))
    setIsSaving(false)
    setSaved(true)
    setTimeout(() => setSaved(false), 3000)
  }

  return (
    <div className="p-6 max-w-3xl mx-auto space-y-8">
      {/* Header */}
      <div>
        <h1 className="text-2xl font-bold text-white">Settings</h1>
        <p className="text-zinc-500 mt-1">Manage your account and preferences</p>
      </div>

      {/* Profile Settings */}
      <section className="bg-zinc-900/80 border border-zinc-800 rounded-xl overflow-hidden">
        <div className="px-6 py-4 border-b border-zinc-800">
          <h2 className="text-lg font-semibold text-white">Profile Settings</h2>
          <p className="text-sm text-zinc-500 mt-1">Update your personal information</p>
        </div>

        <div className="p-6 space-y-5">
          {/* Name field */}
          <div className="space-y-2">
            <label className="text-sm font-medium text-zinc-300 flex items-center gap-2">
              <User className="h-4 w-4 text-zinc-500" />
              Display Name
            </label>
            <Input
              value={profile.name}
              onChange={(e) => handleProfileChange("name", e.target.value)}
              placeholder="Your display name"
              className="bg-zinc-800/50 border-zinc-700 text-white placeholder:text-zinc-500 focus-visible:border-purple-500 focus-visible:ring-purple-500/20"
            />
          </div>

          {/* Email field */}
          <div className="space-y-2">
            <label className="text-sm font-medium text-zinc-300 flex items-center gap-2">
              <Mail className="h-4 w-4 text-zinc-500" />
              Email Address
            </label>
            <Input
              type="email"
              value={profile.email}
              onChange={(e) => handleProfileChange("email", e.target.value)}
              placeholder="your@email.com"
              className="bg-zinc-800/50 border-zinc-700 text-white placeholder:text-zinc-500 focus-visible:border-purple-500 focus-visible:ring-purple-500/20"
            />
          </div>
        </div>
      </section>

      {/* App Preferences */}
      <section className="bg-zinc-900/80 border border-zinc-800 rounded-xl overflow-hidden">
        <div className="px-6 py-4 border-b border-zinc-800">
          <h2 className="text-lg font-semibold text-white">Preferences</h2>
          <p className="text-sm text-zinc-500 mt-1">Customize your app experience</p>
        </div>

        <div className="p-6 space-y-3">
          {/* Dark Mode Toggle */}
          <SettingToggle
            icon={settings.darkMode ? Moon : Sun}
            label="Dark Mode"
            description="Use dark theme across the app"
            enabled={settings.darkMode}
            onToggle={() => handleSettingToggle("darkMode")}
          />

          {/* Sound Effects Toggle */}
          <SettingToggle
            icon={Volume2}
            label="Sound Effects"
            description="Play sounds for donation alerts"
            enabled={settings.soundEffects}
            onToggle={() => handleSettingToggle("soundEffects")}
          />

          {/* Donation Animations Toggle */}
          <SettingToggle
            icon={Sparkles}
            label="Donation Animations"
            description="Show animated alerts on new donations"
            enabled={settings.donationAnimations}
            onToggle={() => handleSettingToggle("donationAnimations")}
          />
        </div>
      </section>

      {/* Save Button */}
      <div className="flex justify-end">
        <Button
          onClick={handleSave}
          disabled={isSaving}
          className={cn(
            "min-w-[140px] transition-all",
            saved
              ? "bg-green-600 hover:bg-green-600"
              : "bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-500 hover:to-pink-500"
          )}
        >
          {isSaving ? (
            <span className="flex items-center gap-2">
              <span className="h-4 w-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
              Saving...
            </span>
          ) : saved ? (
            <span className="flex items-center gap-2">
              <Check className="h-4 w-4" />
              Saved
            </span>
          ) : (
            <span className="flex items-center gap-2">
              <Save className="h-4 w-4" />
              Save Changes
            </span>
          )}
        </Button>
      </div>
    </div>
  )
}

interface SettingToggleProps {
  icon: React.ElementType
  label: string
  description: string
  enabled: boolean
  onToggle: () => void
}

function SettingToggle({ icon: Icon, label, description, enabled, onToggle }: SettingToggleProps) {
  return (
    <div
      className={cn(
        "flex items-center justify-between p-4 rounded-lg transition-all",
        enabled
          ? "bg-purple-500/10 border border-purple-500/30"
          : "bg-zinc-800/50 border border-transparent"
      )}
    >
      <div className="flex items-center gap-4">
        <div
          className={cn(
            "p-2.5 rounded-lg",
            enabled ? "bg-purple-500/20" : "bg-zinc-700/50"
          )}
        >
          <Icon
            className={cn(
              "h-5 w-5",
              enabled ? "text-purple-400" : "text-zinc-500"
            )}
          />
        </div>
        <div>
          <p className={cn("font-medium", enabled ? "text-white" : "text-zinc-400")}>
            {label}
          </p>
          <p className="text-sm text-zinc-500">{description}</p>
        </div>
      </div>
      <Switch
        checked={enabled}
        onCheckedChange={onToggle}
        className="data-[state=checked]:bg-purple-500"
      />
    </div>
  )
}
