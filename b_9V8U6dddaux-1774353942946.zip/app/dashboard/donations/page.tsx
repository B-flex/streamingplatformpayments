"use client"

import { useState, useEffect, useMemo } from "react"
import { DonationTable } from "@/components/donations/donation-table"
import type { DonationRecord } from "@/components/donations/donation-row"
import { Input } from "@/components/ui/input"
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select"
import { Search, Filter, TrendingUp, Wallet } from "lucide-react"

// Mock data - will be replaced with API fetch
const mockDonations: DonationRecord[] = [
  { id: "1", donorName: "TechNinja99", amount: 50000, date: new Date(Date.now() - 1000 * 60 * 5), status: "completed" },
  { id: "2", donorName: "GamerPro", amount: 15000, date: new Date(Date.now() - 1000 * 60 * 30), status: "completed" },
  { id: "3", donorName: "StreamFan", amount: 2500, date: new Date(Date.now() - 1000 * 60 * 60), status: "completed" },
  { id: "4", donorName: "Anonymous", amount: 75000, date: new Date(Date.now() - 1000 * 60 * 120), status: "completed" },
  { id: "5", donorName: "CoolViewer", amount: 7500, date: new Date(Date.now() - 1000 * 60 * 180), status: "pending" },
  { id: "6", donorName: "NightOwl", amount: 3000, date: new Date(Date.now() - 1000 * 60 * 240), status: "completed" },
  { id: "7", donorName: "DayWatcher", amount: 25000, date: new Date(Date.now() - 1000 * 60 * 300), status: "completed" },
  { id: "8", donorName: "SupporterOne", amount: 10000, date: new Date(Date.now() - 1000 * 60 * 400), status: "failed" },
  { id: "9", donorName: "BigFan2024", amount: 35000, date: new Date(Date.now() - 1000 * 60 * 500), status: "completed" },
  { id: "10", donorName: "QuietDonor", amount: 5000, date: new Date(Date.now() - 1000 * 60 * 600), status: "completed" },
  { id: "11", donorName: "StreamLover", amount: 12000, date: new Date(Date.now() - 1000 * 60 * 700), status: "completed" },
  { id: "12", donorName: "MidnightViewer", amount: 8500, date: new Date(Date.now() - 1000 * 60 * 800), status: "pending" },
]

type StatusFilter = "all" | "completed" | "pending" | "failed"
type AmountFilter = "all" | "small" | "medium" | "large"

export default function DonationsPage() {
  const [donations, setDonations] = useState<DonationRecord[]>([])
  const [isLoading, setIsLoading] = useState(true)
  const [searchQuery, setSearchQuery] = useState("")
  const [statusFilter, setStatusFilter] = useState<StatusFilter>("all")
  const [amountFilter, setAmountFilter] = useState<AmountFilter>("all")

  // Simulate API fetch
  useEffect(() => {
    const fetchDonations = async () => {
      setIsLoading(true)
      try {
        // In production, replace with actual API call:
        // const response = await fetch('/api/donations')
        // const data = await response.json()
        // setDonations(data)
        
        // Simulate network delay
        await new Promise((resolve) => setTimeout(resolve, 1000))
        setDonations(mockDonations)
      } catch (error) {
        console.error("Failed to fetch donations:", error)
      } finally {
        setIsLoading(false)
      }
    }

    fetchDonations()
  }, [])

  // Filter and sort donations
  const filteredDonations = useMemo(() => {
    let result = [...donations]

    // Search filter
    if (searchQuery) {
      const query = searchQuery.toLowerCase()
      result = result.filter((d) =>
        d.donorName.toLowerCase().includes(query)
      )
    }

    // Status filter
    if (statusFilter !== "all") {
      result = result.filter((d) => d.status === statusFilter)
    }

    // Amount filter
    if (amountFilter !== "all") {
      result = result.filter((d) => {
        switch (amountFilter) {
          case "small":
            return d.amount < 5000
          case "medium":
            return d.amount >= 5000 && d.amount < 20000
          case "large":
            return d.amount >= 20000
          default:
            return true
        }
      })
    }

    // Sort by date (most recent first)
    result.sort((a, b) => b.date.getTime() - a.date.getTime())

    return result
  }, [donations, searchQuery, statusFilter, amountFilter])

  // Calculate stats
  const stats = useMemo(() => {
    const total = donations.reduce((sum, d) => sum + d.amount, 0)
    const completed = donations.filter((d) => d.status === "completed").length
    return { total, completed, count: donations.length }
  }, [donations])

  return (
    <div className="p-6 lg:p-8 space-y-6">
      {/* Header */}
      <div className="space-y-1">
        <h1 className="text-2xl font-bold text-white">Donations</h1>
        <p className="text-zinc-500">View and manage all your donation history.</p>
      </div>

      {/* Quick Stats */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="bg-zinc-900/80 border border-zinc-800 rounded-xl p-4 flex items-center gap-4">
          <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-purple-500/20 to-pink-500/20 flex items-center justify-center">
            <Wallet className="w-6 h-6 text-purple-400" />
          </div>
          <div>
            <p className="text-sm text-zinc-500">Total Received</p>
            <p className="text-xl font-bold text-white">₦{stats.total.toLocaleString()}</p>
          </div>
        </div>
        <div className="bg-zinc-900/80 border border-zinc-800 rounded-xl p-4 flex items-center gap-4">
          <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-emerald-500/20 to-teal-500/20 flex items-center justify-center">
            <TrendingUp className="w-6 h-6 text-emerald-400" />
          </div>
          <div>
            <p className="text-sm text-zinc-500">Completed</p>
            <p className="text-xl font-bold text-white">{stats.completed} donations</p>
          </div>
        </div>
        <div className="bg-zinc-900/80 border border-zinc-800 rounded-xl p-4 flex items-center gap-4">
          <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-amber-500/20 to-orange-500/20 flex items-center justify-center">
            <Filter className="w-6 h-6 text-amber-400" />
          </div>
          <div>
            <p className="text-sm text-zinc-500">Showing</p>
            <p className="text-xl font-bold text-white">{filteredDonations.length} of {stats.count}</p>
          </div>
        </div>
      </div>

      {/* Search and Filters */}
      <div className="flex flex-col sm:flex-row gap-4">
        {/* Search */}
        <div className="relative flex-1 max-w-md">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-zinc-500" />
          <Input
            placeholder="Search by donor name..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pl-10 bg-zinc-900/80 border-zinc-800 text-white placeholder:text-zinc-600 focus-visible:border-purple-500 focus-visible:ring-purple-500/20"
          />
        </div>

        {/* Status Filter */}
        <Select value={statusFilter} onValueChange={(v) => setStatusFilter(v as StatusFilter)}>
          <SelectTrigger className="w-[160px] bg-zinc-900/80 border-zinc-800 text-white">
            <SelectValue placeholder="Status" />
          </SelectTrigger>
          <SelectContent className="bg-zinc-900 border-zinc-800">
            <SelectItem value="all" className="text-white focus:bg-zinc-800 focus:text-white">All Status</SelectItem>
            <SelectItem value="completed" className="text-white focus:bg-zinc-800 focus:text-white">Completed</SelectItem>
            <SelectItem value="pending" className="text-white focus:bg-zinc-800 focus:text-white">Pending</SelectItem>
            <SelectItem value="failed" className="text-white focus:bg-zinc-800 focus:text-white">Failed</SelectItem>
          </SelectContent>
        </Select>

        {/* Amount Filter */}
        <Select value={amountFilter} onValueChange={(v) => setAmountFilter(v as AmountFilter)}>
          <SelectTrigger className="w-[160px] bg-zinc-900/80 border-zinc-800 text-white">
            <SelectValue placeholder="Amount" />
          </SelectTrigger>
          <SelectContent className="bg-zinc-900 border-zinc-800">
            <SelectItem value="all" className="text-white focus:bg-zinc-800 focus:text-white">All Amounts</SelectItem>
            <SelectItem value="small" className="text-white focus:bg-zinc-800 focus:text-white">Under ₦5,000</SelectItem>
            <SelectItem value="medium" className="text-white focus:bg-zinc-800 focus:text-white">₦5,000 - ₦20,000</SelectItem>
            <SelectItem value="large" className="text-white focus:bg-zinc-800 focus:text-white">Over ₦20,000</SelectItem>
          </SelectContent>
        </Select>
      </div>

      {/* Donations Table */}
      <DonationTable
        donations={filteredDonations}
        isLoading={isLoading}
        largeDonationThreshold={20000}
      />
    </div>
  )
}
