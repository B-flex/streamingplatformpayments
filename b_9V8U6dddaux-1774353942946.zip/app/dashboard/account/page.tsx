"use client"

import { cn } from "@/lib/utils"
import { 
  Copy, 
  Check, 
  Building2, 
  CreditCard, 
  User, 
  QrCode, 
  Shield, 
  Clock, 
  Zap,
  Info,
  ExternalLink,
  Download
} from "lucide-react"
import { useState } from "react"

// Mock account data - would come from API in production
const accountData = {
  accountName: "StreamTip/OluwaCreator",
  accountNumber: "8012345678",
  bankName: "Wema Bank",
  reference: "STIP-2024-XYZ789",
}

export default function VirtualAccountPage() {
  const [copiedField, setCopiedField] = useState<string | null>(null)

  const copyToClipboard = async (text: string, field: string) => {
    await navigator.clipboard.writeText(text)
    setCopiedField(field)
    setTimeout(() => setCopiedField(null), 2000)
  }

  const accountFields = [
    { 
      label: "Bank Name", 
      value: accountData.bankName, 
      field: "bank",
      icon: Building2,
      highlight: false
    },
    { 
      label: "Account Number", 
      value: accountData.accountNumber, 
      field: "number",
      icon: CreditCard,
      highlight: true
    },
    { 
      label: "Account Name", 
      value: accountData.accountName, 
      field: "name",
      icon: User,
      highlight: false
    },
  ]

  return (
    <div className="p-6 space-y-6 max-w-5xl">
      {/* Page header */}
      <div>
        <h1 className="text-2xl font-bold text-white">Virtual Account</h1>
        <p className="text-zinc-400 mt-1">
          Your dedicated account for receiving donations
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Main account card */}
        <div className="bg-gradient-to-br from-zinc-900 to-zinc-950 border border-zinc-800 rounded-xl overflow-hidden">
          {/* Header with neon accent */}
          <div className="px-6 py-5 border-b border-zinc-800 bg-gradient-to-r from-purple-500/10 via-pink-500/10 to-purple-500/10">
            <div className="flex items-center gap-3">
              <div className="p-2.5 rounded-xl bg-gradient-to-br from-purple-500 to-pink-500 shadow-lg shadow-purple-500/25">
                <CreditCard className="h-5 w-5 text-white" />
              </div>
              <div>
                <h2 className="text-lg font-semibold text-white">Account Details</h2>
                <p className="text-sm text-zinc-500">Share with your viewers</p>
              </div>
            </div>
          </div>
          
          {/* Account details with neon highlights */}
          <div className="p-6 space-y-4">
            {accountFields.map(({ label, value, field, icon: Icon, highlight }) => (
              <div 
                key={field}
                className={cn(
                  "relative flex items-center justify-between p-4 rounded-xl transition-all duration-300",
                  "group hover:scale-[1.02]",
                  highlight 
                    ? "bg-gradient-to-r from-purple-500/20 to-pink-500/20 border border-purple-500/40 shadow-lg shadow-purple-500/10" 
                    : "bg-zinc-800/50 border border-zinc-700/50 hover:border-zinc-600"
                )}
              >
                {/* Neon glow effect for highlighted field */}
                {highlight && (
                  <div className="absolute inset-0 rounded-xl bg-gradient-to-r from-purple-500/10 to-pink-500/10 blur-xl opacity-50" />
                )}
                
                <div className="relative flex items-center gap-4">
                  <div className={cn(
                    "p-2.5 rounded-lg",
                    highlight 
                      ? "bg-gradient-to-br from-purple-500 to-pink-500" 
                      : "bg-zinc-700/50"
                  )}>
                    <Icon className={cn(
                      "h-5 w-5",
                      highlight ? "text-white" : "text-zinc-400"
                    )} />
                  </div>
                  <div>
                    <p className="text-xs text-zinc-500 uppercase tracking-wider">{label}</p>
                    <p className={cn(
                      "text-lg font-semibold mt-0.5",
                      highlight 
                        ? "text-transparent bg-clip-text bg-gradient-to-r from-purple-400 to-pink-400" 
                        : "text-white"
                    )}>
                      {value}
                    </p>
                  </div>
                </div>
                <button
                  onClick={() => copyToClipboard(value, field)}
                  className={cn(
                    "relative p-2.5 rounded-lg transition-all duration-200",
                    highlight 
                      ? "text-purple-400 hover:text-white hover:bg-purple-500/20" 
                      : "text-zinc-500 hover:text-white hover:bg-zinc-700"
                  )}
                  title={`Copy ${label}`}
                >
                  {copiedField === field ? (
                    <Check className="h-5 w-5 text-emerald-400" />
                  ) : (
                    <Copy className="h-5 w-5" />
                  )}
                </button>
              </div>
            ))}
          </div>

          {/* Copy all button */}
          <div className="px-6 pb-6">
            <button
              onClick={() => copyToClipboard(
                `Bank: ${accountData.bankName}\nAccount Number: ${accountData.accountNumber}\nAccount Name: ${accountData.accountName}`,
                "all"
              )}
              className={cn(
                "w-full py-3.5 rounded-xl text-sm font-semibold transition-all duration-300",
                "bg-gradient-to-r from-purple-500 to-pink-500 text-white",
                "hover:from-purple-600 hover:to-pink-600 hover:shadow-lg hover:shadow-purple-500/25",
                "active:scale-[0.98]"
              )}
            >
              {copiedField === "all" ? (
                <span className="flex items-center justify-center gap-2">
                  <Check className="h-4 w-4" />
                  Copied All Details!
                </span>
              ) : (
                <span className="flex items-center justify-center gap-2">
                  <Copy className="h-4 w-4" />
                  Copy All Details
                </span>
              )}
            </button>
          </div>
        </div>

        {/* QR Code card */}
        <div className="bg-gradient-to-br from-zinc-900 to-zinc-950 border border-zinc-800 rounded-xl overflow-hidden">
          <div className="px-6 py-5 border-b border-zinc-800">
            <div className="flex items-center gap-3">
              <div className="p-2.5 rounded-xl bg-zinc-800">
                <QrCode className="h-5 w-5 text-zinc-400" />
              </div>
              <div>
                <h2 className="text-lg font-semibold text-white">QR Code</h2>
                <p className="text-sm text-zinc-500">Scan to get account details</p>
              </div>
            </div>
          </div>
          
          <div className="p-6 flex flex-col items-center">
            {/* QR Code placeholder */}
            <div className="relative p-4 bg-white rounded-2xl shadow-xl">
              <div className="w-48 h-48 bg-zinc-100 rounded-lg flex items-center justify-center relative overflow-hidden">
                {/* QR pattern placeholder */}
                <div className="absolute inset-2 grid grid-cols-8 grid-rows-8 gap-1">
                  {Array.from({ length: 64 }).map((_, i) => (
                    <div 
                      key={i}
                      className={cn(
                        "rounded-sm",
                        Math.random() > 0.5 ? "bg-zinc-900" : "bg-transparent"
                      )}
                    />
                  ))}
                </div>
                {/* Center logo */}
                <div className="absolute inset-0 flex items-center justify-center">
                  <div className="p-2 bg-white rounded-lg shadow-sm">
                    <div className="w-8 h-8 rounded bg-gradient-to-br from-purple-500 to-pink-500 flex items-center justify-center">
                      <Zap className="h-4 w-4 text-white" />
                    </div>
                  </div>
                </div>
              </div>
            </div>
            
            <p className="text-sm text-zinc-500 mt-4 text-center">
              Viewers can scan this code to quickly<br />access your donation details
            </p>

            <button className="mt-4 flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-medium text-zinc-400 hover:text-white bg-zinc-800/50 hover:bg-zinc-800 transition-colors">
              <Download className="h-4 w-4" />
              Download QR Code
            </button>
          </div>
        </div>
      </div>

      {/* Instructions card */}
      <div className="bg-gradient-to-br from-zinc-900 to-zinc-950 border border-zinc-800 rounded-xl overflow-hidden">
        <div className="px-6 py-5 border-b border-zinc-800 flex items-center gap-3">
          <div className="p-2.5 rounded-xl bg-cyan-500/10 border border-cyan-500/20">
            <Info className="h-5 w-5 text-cyan-400" />
          </div>
          <div>
            <h2 className="text-lg font-semibold text-white">How Donations Work</h2>
            <p className="text-sm text-zinc-500">Instructions for your viewers</p>
          </div>
        </div>
        
        <div className="p-6">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {/* Step 1 */}
            <div className="flex gap-4">
              <div className="flex-shrink-0 w-10 h-10 rounded-full bg-gradient-to-br from-purple-500 to-pink-500 flex items-center justify-center text-white font-bold shadow-lg shadow-purple-500/25">
                1
              </div>
              <div>
                <h3 className="font-semibold text-white">Open Banking App</h3>
                <p className="text-sm text-zinc-400 mt-1">
                  Open your mobile banking app or USSD and select transfer to bank
                </p>
              </div>
            </div>

            {/* Step 2 */}
            <div className="flex gap-4">
              <div className="flex-shrink-0 w-10 h-10 rounded-full bg-gradient-to-br from-purple-500 to-pink-500 flex items-center justify-center text-white font-bold shadow-lg shadow-purple-500/25">
                2
              </div>
              <div>
                <h3 className="font-semibold text-white">Enter Details</h3>
                <p className="text-sm text-zinc-400 mt-1">
                  Enter the account number and select {accountData.bankName} as the bank
                </p>
              </div>
            </div>

            {/* Step 3 */}
            <div className="flex gap-4">
              <div className="flex-shrink-0 w-10 h-10 rounded-full bg-gradient-to-br from-purple-500 to-pink-500 flex items-center justify-center text-white font-bold shadow-lg shadow-purple-500/25">
                3
              </div>
              <div>
                <h3 className="font-semibold text-white">Send & Appear on Stream</h3>
                <p className="text-sm text-zinc-400 mt-1">
                  Complete transfer and your donation will appear on stream instantly!
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Trust indicators */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="flex items-center gap-3 p-4 bg-zinc-900/50 border border-zinc-800 rounded-xl">
          <div className="p-2 rounded-lg bg-emerald-500/10">
            <Shield className="h-5 w-5 text-emerald-400" />
          </div>
          <div>
            <p className="text-sm font-medium text-white">Secure Payments</p>
            <p className="text-xs text-zinc-500">Bank-grade security</p>
          </div>
        </div>

        <div className="flex items-center gap-3 p-4 bg-zinc-900/50 border border-zinc-800 rounded-xl">
          <div className="p-2 rounded-lg bg-cyan-500/10">
            <Clock className="h-5 w-5 text-cyan-400" />
          </div>
          <div>
            <p className="text-sm font-medium text-white">Instant Alerts</p>
            <p className="text-xs text-zinc-500">Shows within seconds</p>
          </div>
        </div>

        <div className="flex items-center gap-3 p-4 bg-zinc-900/50 border border-zinc-800 rounded-xl">
          <div className="p-2 rounded-lg bg-purple-500/10">
            <Zap className="h-5 w-5 text-purple-400" />
          </div>
          <div>
            <p className="text-sm font-medium text-white">No Fees</p>
            <p className="text-xs text-zinc-500">You receive 100%</p>
          </div>
        </div>
      </div>

      {/* Shareable link section */}
      <div className="bg-zinc-900/50 border border-zinc-800 rounded-xl p-5">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <h3 className="font-semibold text-white">Shareable Donation Link</h3>
            <p className="text-sm text-zinc-500 mt-0.5">Share this link for viewers to donate directly</p>
          </div>
          <div className="flex items-center gap-2">
            <div className="px-4 py-2 bg-zinc-800 rounded-lg text-sm text-zinc-300 font-mono truncate max-w-xs">
              streamtip.ng/donate/oluwacreator
            </div>
            <button 
              onClick={() => copyToClipboard("https://streamtip.ng/donate/oluwacreator", "link")}
              className="p-2 rounded-lg text-zinc-400 hover:text-white hover:bg-zinc-800 transition-colors"
            >
              {copiedField === "link" ? (
                <Check className="h-5 w-5 text-emerald-400" />
              ) : (
                <Copy className="h-5 w-5" />
              )}
            </button>
            <button className="p-2 rounded-lg text-zinc-400 hover:text-white hover:bg-zinc-800 transition-colors">
              <ExternalLink className="h-5 w-5" />
            </button>
          </div>
        </div>
      </div>
    </div>
  )
}
