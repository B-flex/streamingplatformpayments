"use client"

import { StatsCard } from "@/components/dashboard/stats-card"
import { DonationsTable, type Donation } from "@/components/dashboard/donations-table"
import { VirtualAccountCard } from "@/components/dashboard/virtual-account-card"
import { AnimationToggle, defaultOverlaySettings } from "@/components/dashboard/animation-toggle"
import { Wallet, Users, TrendingUp, Gift } from "lucide-react"
import { useState } from "react"

// Sample data - in production, fetch from API
const sampleDonations: Donation[] = [
  { id: "1", senderName: "TechNinja99", amount: 5000, message: "Great stream!", createdAt: new Date(Date.now() - 1000 * 60 * 5) },
  { id: "2", senderName: "GamerPro", amount: 15000, message: "Keep up the good work", createdAt: new Date(Date.now() - 1000 * 60 * 15) },
  { id: "3", senderName: "StreamFan", amount: 2500, createdAt: new Date(Date.now() - 1000 * 60 * 30) },
  { id: "4", senderName: "Anonymous", amount: 50000, message: "You deserve this!", createdAt: new Date(Date.now() - 1000 * 60 * 60) },
  { id: "5", senderName: "CoolViewer", amount: 7500, message: "Love your content", createdAt: new Date(Date.now() - 1000 * 60 * 90) },
  { id: "6", senderName: "NightOwl", amount: 3000, createdAt: new Date(Date.now() - 1000 * 60 * 120) },
  { id: "7", senderName: "DayWatcher", amount: 10000, message: "Amazing gameplay!", createdAt: new Date(Date.now() - 1000 * 60 * 180) },
]

const virtualAccount = {
  accountName: "StreamTip/YourUsername",
  accountNumber: "8012345678",
  bankName: "Wema Bank",
}

export default function DashboardPage() {
  const [overlaySettings, setOverlaySettings] = useState(defaultOverlaySettings)

  const handleToggle = (id: string, enabled: boolean) => {
    setOverlaySettings((prev) =>
      prev.map((item) => (item.id === id ? { ...item, enabled } : item))
    )
  }

  const totalEarnings = sampleDonations.reduce((sum, d) => sum + d.amount, 0)
  const totalDonations = sampleDonations.length
  const uniqueDonors = new Set(sampleDonations.map(d => d.senderName)).size
  const avgDonation = Math.round(totalEarnings / totalDonations)

  return (
    <div className="p-6 lg:p-8 space-y-6">
      {/* Header */}
      <div className="space-y-1">
        <h1 className="text-2xl font-bold text-white">Dashboard</h1>
        <p className="text-zinc-500">Welcome back! Here{"'"}s your streaming overview.</p>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-4">
        <StatsCard
          title="Total Earnings"
          value={`₦${totalEarnings.toLocaleString()}`}
          subtitle="All time"
          icon={Wallet}
          variant="purple"
          trend={{ value: 12, isPositive: true }}
        />
        <StatsCard
          title="Total Donations"
          value={totalDonations}
          subtitle="This month"
          icon={Gift}
          variant="green"
          trend={{ value: 8, isPositive: true }}
        />
        <StatsCard
          title="Unique Donors"
          value={uniqueDonors}
          subtitle="All time"
          icon={Users}
          variant="amber"
        />
        <StatsCard
          title="Average Donation"
          value={`₦${avgDonation.toLocaleString()}`}
          subtitle="Per transaction"
          icon={TrendingUp}
        />
      </div>

      {/* Main Content Grid */}
      <div className="grid grid-cols-1 xl:grid-cols-3 gap-6">
        {/* Donations Table - spans 2 columns on xl */}
        <div className="xl:col-span-2">
          <DonationsTable donations={sampleDonations} />
        </div>

        {/* Sidebar widgets */}
        <div className="space-y-6">
          <VirtualAccountCard account={virtualAccount} />
          <AnimationToggle 
            settings={overlaySettings} 
            onToggle={handleToggle} 
          />
        </div>
      </div>
    </div>
  )
}
