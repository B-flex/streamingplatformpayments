import { Overlay } from "@/components/overlay"

export default function Page() {
  return <Overlay />
}
